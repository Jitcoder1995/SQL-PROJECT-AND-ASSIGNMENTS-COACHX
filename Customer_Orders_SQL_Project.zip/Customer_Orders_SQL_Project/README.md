# Customer Orders & Products SQL Project

**Database:** MySQL 8.0+  
**Run order:** `sql/01_schema_and_data.sql`, then `sql/02_business_questions.sql`.  
Run `sql/03_optional_product_categories.sql` only for category exercises.

This project models customers, products and orders. It includes table creation, sample data, 20 assignment solutions and bonus business reports.

The project uses `ProductID` as a foreign key in `orders` (a normalized design), rather than joining tables by product-name text.

**Sample-data checks:** 12 customers, 12 products, 15 orders, 46 units ordered. Average product price = 9.6567 (9.66 rounded). Category values in the optional script are illustrative only; the source assignment did not supply categories.
