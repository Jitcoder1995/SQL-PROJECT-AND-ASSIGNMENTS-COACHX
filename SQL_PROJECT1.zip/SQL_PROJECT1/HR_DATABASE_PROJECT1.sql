
    CREATE DATABASE HRDatabase;

USE HRDatabase;



CREATE TABLE regions
(
    region_id INT NOT NULL PRIMARY KEY,
    region_name VARCHAR(25) NULL
);

CREATE TABLE countries
(
    country_id CHAR(2) NOT NULL PRIMARY KEY,
    country_name VARCHAR(40) NULL,
    region_id INT NOT NULL,
    CONSTRAINT FK_countries_regions
        FOREIGN KEY (region_id) REFERENCES regions(region_id)
);

CREATE TABLE locations
(
    location_id INT NOT NULL PRIMARY KEY,
    street_address VARCHAR(40) NULL,
    postal_code VARCHAR(12) NULL,
    city VARCHAR(30) NOT NULL,
    state_province VARCHAR(25) NULL,
    country_id CHAR(2) NOT NULL,
    CONSTRAINT FK_locations_countries
        FOREIGN KEY (country_id) REFERENCES countries(country_id)
);

CREATE TABLE jobs
(
    job_id INT NOT NULL PRIMARY KEY,
    job_title VARCHAR(35) NOT NULL,
    min_salary DECIMAL(8,2) NULL,
    max_salary DECIMAL(8,2) NULL
);

CREATE TABLE departments
(
    department_id INT NOT NULL PRIMARY KEY,
    department_name VARCHAR(30) NOT NULL,
    location_id INT NULL,
    CONSTRAINT FK_departments_locations
        FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

CREATE TABLE employees
(
    employee_id INT NOT NULL PRIMARY KEY,
    first_name VARCHAR(20) NULL,
    last_name VARCHAR(25) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20) NULL,
    hire_date DATE NOT NULL,
    job_id INT NOT NULL,
    salary DECIMAL(8,2) NOT NULL,
    manager_id INT NULL,
    department_id INT NULL,
    CONSTRAINT FK_employees_jobs
        FOREIGN KEY (job_id) REFERENCES jobs(job_id),
    CONSTRAINT FK_employees_departments
        FOREIGN KEY (department_id) REFERENCES departments(department_id),
    CONSTRAINT FK_employees_manager
        FOREIGN KEY (manager_id) REFERENCES employees(employee_id)
);

CREATE TABLE dependents
(
    dependent_id INT NOT NULL PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    relationship VARCHAR(25) NOT NULL,
    employee_id INT NOT NULL,
    CONSTRAINT FK_dependents_employees
        FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);


/* 2. INSERT SAMPLE DATA FROM THE ASSIGNMENT */
/* Source-data correction: dependent_id 1 references employee_id 206, but employee 206 is absent from the supplied employee records. That row is intentionally omitted to preserve the foreign key. */
INSERT INTO regions(region_id,region_name) VALUES (1,'Europe');
INSERT INTO regions(region_id,region_name) VALUES (2,'Americas');
INSERT INTO regions(region_id,region_name) VALUES (3,'Asia');
INSERT INTO regions(region_id,region_name) VALUES (4,'Middle East and Africa');
INSERT INTO countries(country_id,country_name,region_id) VALUES ('AR','Argentina',2);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('AU','Australia',3);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('BE','Belgium',1);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('BR','Brazil',2);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('CA','Canada',2);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('CH','Switzerland',1);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('CN','China',3);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('DE','Germany',1);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('DK','Denmark',1);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('EG','Egypt',4);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('FR','France',1);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('HK','HongKong',3);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('IL','Israel',4);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('IN','India',3);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('IT','Italy',1);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('JP','Japan',3);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('KW','Kuwait',4);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('MX','Mexico',2);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('NG','Nigeria',4);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('NL','Netherlands',1);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('SG','Singapore',3);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('UK','United Kingdom',1);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('US','United States of America',2);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('ZM','Zambia',4);
INSERT INTO countries(country_id,country_name,region_id) VALUES ('ZW','Zimbabwe',4);
INSERT INTO locations(location_id,street_address,postal_code,city,state_province,country_id) VALUES (1400,'2014 Jabberwocky Rd','26192','Southlake','Texas','US');
INSERT INTO locations(location_id,street_address,postal_code,city,state_province,country_id) VALUES (1500,'2011 Interiors Blvd','99236','South San Francisco','California','US');
INSERT INTO locations(location_id,street_address,postal_code,city,state_province,country_id) VALUES (1700,'2004 Charade Rd','98199','Seattle','Washington','US');
INSERT INTO locations(location_id,street_address,postal_code,city,state_province,country_id) VALUES (1800,'147 Spadina Ave','M5V 2L7','Toronto','Ontario','CA');
INSERT INTO locations(location_id,street_address,postal_code,city,state_province,country_id) VALUES (2400,'8204 Arthur St',NULL,'London',NULL,'UK');
INSERT INTO locations(location_id,street_address,postal_code,city,state_province,country_id) VALUES (2500,'Magdalen Centre, The Oxford Science Park','OX9 9ZB','Oxford','Oxford','UK');
INSERT INTO locations(location_id,street_address,postal_code,city,state_province,country_id) VALUES (2700,'Schwanthalerstr. 7031','80925','Munich','Bavaria','DE');
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (1,'Public Accountant',4200.00,9000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (2,'Accounting Manager',8200.00,16000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (3,'Administration Assistant',3000.00,6000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (4,'President',20000.00,40000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (5,'Administration Vice President',15000.00,30000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (6,'Accountant',4200.00,9000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (7,'Finance Manager',8200.00,16000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (8,'Human Resources Representative',4000.00,9000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (9,'Programmer',4000.00,10000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (10,'Marketing Manager',9000.00,15000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (11,'Marketing Representative',4000.00,9000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (12,'Public Relations Representative',4500.00,10500.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (13,'Purchasing Clerk',2500.00,5500.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (14,'Purchasing Manager',8000.00,15000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (15,'Sales Manager',10000.00,20000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (16,'Sales Representative',6000.00,12000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (17,'Shipping Clerk',2500.00,5500.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (18,'Stock Clerk',2000.00,5000.00);
INSERT INTO jobs(job_id,job_title,min_salary,max_salary) VALUES (19,'Stock Manager',5500.00,8500.00);
INSERT INTO departments(department_id,department_name,location_id) VALUES (1,'Administration',1700);
INSERT INTO departments(department_id,department_name,location_id) VALUES (2,'Marketing',1800);
INSERT INTO departments(department_id,department_name,location_id) VALUES (3,'Purchasing',1700);
INSERT INTO departments(department_id,department_name,location_id) VALUES (4,'Human Resources',2400);
INSERT INTO departments(department_id,department_name,location_id) VALUES (5,'Shipping',1500);
INSERT INTO departments(department_id,department_name,location_id) VALUES (6,'IT',1400);
INSERT INTO departments(department_id,department_name,location_id) VALUES (7,'Public Relations',2700);
INSERT INTO departments(department_id,department_name,location_id) VALUES (8,'Sales',2500);
INSERT INTO departments(department_id,department_name,location_id) VALUES (9,'Executive',1700);
INSERT INTO departments(department_id,department_name,location_id) VALUES (10,'Finance',1700);
INSERT INTO departments(department_id,department_name,location_id) VALUES (11,'Accounting',1700);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (100,'Steven','King','steven.king@sqltutorial.org','515.123.4567','1987-06-17',4,24000.00,NULL,9);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (101,'Neena','Kochhar','neena.kochhar@sqltutorial.org','515.123.4568','1989-09-21',5,17000.00,100,9);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (102,'Lex','De Haan','lex.de haan@sqltutorial.org','515.123.4569','1993-01-13',5,17000.00,100,9);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (103,'Alexander','Hunold','alexander.hunold@sqltutorial.org','590.423.4567','1990-01-03',9,9000.00,102,6);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (104,'Bruce','Ernst','bruce.ernst@sqltutorial.org','590.423.4568','1991-05-21',9,6000.00,103,6);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (105,'David','Austin','david.austin@sqltutorial.org','590.423.4569','1997-06-25',9,4800.00,103,6);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (106,'Valli','Pataballa','valli.pataballa@sqltutorial.org','590.423.4560','1998-02-05',9,4800.00,103,6);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (107,'Diana','Lorentz','diana.lorentz@sqltutorial.org','590.423.5567','1999-02-07',9,4200.00,103,6);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (108,'Nancy','Greenberg','nancy.greenberg@sqltutorial.org','515.124.4569','1994-08-17',7,12000.00,101,10);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (109,'Daniel','Faviet','daniel.faviet@sqltutorial.org','515.124.4169','1994-08-16',6,9000.00,108,10);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (110,'John','Chen','john.chen@sqltutorial.org','515.124.4269','1997-09-28',6,8200.00,108,10);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (111,'Ismael','Sciarra','ismael.sciarra@sqltutorial.org','515.124.4369','1997-09-30',6,7700.00,108,10);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (112,'Jose Manuel','Urman','jose manuel.urman@sqltutorial.org','515.124.4469','1998-03-07',6,7800.00,108,10);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (113,'Luis','Popp','luis.popp@sqltutorial.org','515.124.4567','1999-12-07',6,6900.00,108,10);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (114,'Den','Raphaely','den.raphaely@sqltutorial.org','515.127.4561','1994-12-07',14,11000.00,100,3);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (115,'Alexander','Khoo','alexander.khoo@sqltutorial.org','515.127.4562','1995-05-18',13,3100.00,114,3);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (116,'Shelli','Baida','shelli.baida@sqltutorial.org','515.127.4563','1997-12-24',13,2900.00,114,3);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (117,'Sigal','Tobias','sigal.tobias@sqltutorial.org','515.127.4564','1997-07-24',13,2800.00,114,3);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (118,'Guy','Himuro','guy.himuro@sqltutorial.org','515.127.4565','1998-11-15',13,2600.00,114,3);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (119,'Karen','Colmenares','karen.colmenares@sqltutorial.org','515.127.4566','1999-08-10',13,2500.00,114,3);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (120,'Matthew','Weiss','matthew.weiss@sqltutorial.org','650.123.1234','1996-07-18',19,8000.00,100,5);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (121,'Adam','Fripp','adam.fripp@sqltutorial.org','650.123.2234','1997-04-10',19,8200.00,100,5);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (122,'Payam','Kaufling','payam.kaufling@sqltutorial.org','650.123.3234','1995-05-01',19,7900.00,100,5);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (123,'Shanta','Vollman','shanta.vollman@sqltutorial.org','650.123.4234','1997-10-10',19,6500.00,100,5);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (126,'Irene','Mikkilineni','irene.mikkilineni@sqltutorial.org','650.124.1224','1998-09-28',18,2700.00,120,5);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (145,'John','Russell','john.russell@sqltutorial.org',NULL,'1996-10-01',15,14000.00,100,8);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (146,'Karen','Partners','karen.partners@sqltutorial.org',NULL,'1997-01-05',15,13500.00,100,8);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (176,'Jonathon','Taylor','jonathon.taylor@sqltutorial.org',NULL,'1998-03-24',16,8600.00,100,8);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (177,'Jack','Livingston','jack.livingston@sqltutorial.org',NULL,'1998-04-23',16,8400.00,100,8);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (178,'Kimberely','Grant','kimberely.grant@sqltutorial.org',NULL,'1999-05-24',16,7000.00,100,8);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (179,'Charles','Johnson','charles.johnson@sqltutorial.org',NULL,'2000-01-04',16,6200.00,100,8);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (192,'Sarah','Bell','sarah.bell@sqltutorial.org','650.501.1876','1996-02-04',17,4000.00,123,5);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (193,'Britney','Everett','britney.everett@sqltutorial.org','650.501.2876','1997-03-03',17,3900.00,123,5);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (200,'Jennifer','Whalen','jennifer.whalen@sqltutorial.org','515.123.4444','1987-09-17',3,4400.00,101,1);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (201,'Michael','Hartstein','michael.hartstein@sqltutorial.org','515.123.5555','1996-02-17',10,13000.00,100,2);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (202,'Pat','Fay','pat.fay@sqltutorial.org','603.123.6666','1997-08-17',11,6000.00,201,2);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (203,'Susan','Mavris','susan.mavris@sqltutorial.org','515.123.7777','1994-06-07',8,6500.00,101,4);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (204,'Hermann','Baer','hermann.baer@sqltutorial.org','515.123.8888','1994-06-07',12,10000.00,101,7);
INSERT INTO employees(employee_id,first_name,last_name,email,phone_number,hire_date,job_id,salary,manager_id,department_id) VALUES (205,'Shelley','Higgins','shelley.higgins@sqltutorial.org','515.123.8080','1994-06-07',2,12000.00,101,11);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (2,'Nick','Higgins','Child',205);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (3,'Ed','Whalen','Child',200);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (4,'Jennifer','King','Child',100);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (5,'Johnny','Kochhar','Child',101);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (6,'Bette','De Haan','Child',102);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (7,'Grace','Faviet','Child',109);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (8,'Matthew','Chen','Child',110);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (9,'Joe','Sciarra','Child',111);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (10,'Christian','Urman','Child',112);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (11,'Zero','Popp','Child',113);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (12,'Karl','Greenberg','Child',108);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (13,'Uma','Mavris','Child',203);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (14,'Vivien','Hunold','Child',103);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (15,'Cuba','Ernst','Child',104);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (16,'Fred','Austin','Child',105);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (17,'Helen','Pataballa','Child',106);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (18,'Dan','Lorentz','Child',107);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (19,'Bob','Hartstein','Child',201);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (20,'Lucille','Fay','Child',202);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (21,'Kirsten','Baer','Child',204);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (22,'Elvis','Khoo','Child',115);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (23,'Sandra','Baida','Child',116);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (24,'Cameron','Tobias','Child',117);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (25,'Kevin','Himuro','Child',118);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (26,'Rip','Colmenares','Child',119);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (27,'Julia','Raphaely','Child',114);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (28,'Woody','Russell','Child',145);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (29,'Alec','Partners','Child',146);
INSERT INTO dependents(dependent_id,first_name,last_name,relationship,employee_id) VALUES (30,'Sandra','Taylor','Child',176);


/* ================================================================
   TASK 1 - SELECT, ORDER BY, DISTINCT, TOP, WHERE, DDL, FOREIGN KEY
   ================================================================ */

-- 1. SELECT
-- A. All rows and columns from employees.
SELECT * FROM employees;

-- B. Employee ID, first name, last name and hire date.
SELECT employee_id, first_name, last_name, hire_date
FROM employees;

-- C-D. Display salary and double salary as New_SALARY.
SELECT first_name, last_name, salary, salary * 2 AS New_SALARY
FROM employees;

-- 2. ORDER BY
-- A. Requested columns.
SELECT employee_id, first_name, last_name, hire_date, salary
FROM employees;

-- B. First name A-Z.
SELECT * FROM employees ORDER BY first_name ASC;

-- C. First name ascending, last name descending.
SELECT * FROM employees
ORDER BY first_name ASC, last_name DESC;

-- D. Salary high to low.
SELECT * FROM employees ORDER BY salary DESC;

-- E. Hire date ascending (oldest first).
SELECT * FROM employees ORDER BY hire_date ASC;

-- F. Hire date descending (newest first).
SELECT * FROM employees ORDER BY hire_date DESC;

-- 3. DISTINCT
-- A. Salary values sorted high to low (duplicates retained).
SELECT salary FROM employees ORDER BY salary DESC;

-- B. Unique salaries.
SELECT DISTINCT salary FROM employees ORDER BY salary DESC;

-- C. Job ID and salary, including duplicates.
SELECT job_id, salary FROM employees;

-- D. Unique job ID + salary combinations.
SELECT DISTINCT job_id, salary FROM employees;

-- E. Unique phone numbers (NULL may appear once).
SELECT DISTINCT phone_number FROM employees;

-- 4. TOP
-- A. All employees sorted by first name.
SELECT * FROM employees ORDER BY first_name;

-- B. First five rows (deterministic order).
SELECT TOP (5) * FROM employees ORDER BY employee_id;

-- C. Five rows starting from row 4.
SELECT * FROM employees
ORDER BY employee_id
OFFSET 3 ROWS FETCH NEXT 5 ROWS ONLY;

-- D. Top five highest-paid employees.
SELECT TOP (5) * FROM employees ORDER BY salary DESC, employee_id;

-- E. Employees earning the second-highest distinct salary.
SELECT *
FROM employees
WHERE salary = (SELECT MAX(salary)
                FROM employees
                WHERE salary < (SELECT MAX(salary) FROM employees));

-- 5. WHERE and comparison operators
-- A. Salary greater than 14000, high to low.
SELECT * FROM employees
WHERE salary > 14000 ORDER BY salary DESC;

-- B. Department 5.
SELECT * FROM employees WHERE department_id = 5;

-- C. Last name Chen.
SELECT * FROM employees WHERE last_name = 'Chen';

-- D. Joined after 1 January 1999.
SELECT * FROM employees WHERE hire_date > '1999-01-01';

-- E. Joined during 1999.
SELECT * FROM employees
WHERE hire_date >= '1999-01-01' AND hire_date < '2000-01-01';

-- F. Last name Himuro.
SELECT * FROM employees WHERE last_name = 'Himuro';

-- G. Search for Himuro in last_name.
SELECT * FROM employees WHERE last_name LIKE '%Himuro%';

-- H. No phone number.
SELECT * FROM employees WHERE phone_number IS NULL;

-- I. Department is not 8 (NULL department IDs are excluded).
SELECT * FROM employees WHERE department_id <> 8;

-- J. Department is neither 8 nor 10.
SELECT * FROM employees
WHERE department_id NOT IN (8, 10);

-- K. Salary greater than 10000.
SELECT * FROM employees WHERE salary > 10000;

-- L. Department 8 and salary greater than 10000.
SELECT * FROM employees
WHERE department_id = 8 AND salary > 10000;

-- M. Salary less than 10000.
SELECT * FROM employees WHERE salary < 10000;

-- N. Salary >= 9000.
SELECT * FROM employees WHERE salary >= 9000;

-- O. Salary <= 9000.
SELECT * FROM employees WHERE salary <= 9000;

-- 6. ALTER TABLE examples: courses table is not part of the seven-table HR schema.
CREATE TABLE courses
(
    course_id INT PRIMARY KEY,
    course_name VARCHAR(100) NOT NULL
);
-- A. Add credit_hours.
ALTER TABLE courses ADD credit_hours INT NULL;
-- B. SQL Server does not support positioning columns AFTER another column.
--    Add both columns; their display order can be controlled in SELECT.
ALTER TABLE courses ADD fee DECIMAL(10,2) NULL, max_limit INT NULL;
-- C. Make fee NOT NULL (existing rows, if any, must have a fee first).
ALTER TABLE courses ALTER COLUMN fee DECIMAL(10,2) NOT NULL;
-- D. Drop fee.
ALTER TABLE courses DROP COLUMN fee;
-- E. Drop max_limit and credit_hours.
ALTER TABLE courses DROP COLUMN max_limit, credit_hours;

-- 6 (Foreign key example). Create the parent and child tables with FK at creation.
CREATE TABLE projects
(
    project_id INT PRIMARY KEY,
    project_name VARCHAR(255),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL
);
CREATE TABLE project_milestones
(
    milestone_id INT PRIMARY KEY,
    project_id INT NOT NULL,
    milestone_name VARCHAR(100),
    CONSTRAINT FK_project_milestones_projects
        FOREIGN KEY (project_id) REFERENCES projects(project_id)
);
-- B. Add a foreign key to an existing child table (alternative demonstration).
CREATE TABLE project_milestones_existing
(
    milestone_id INT PRIMARY KEY,
    project_id INT NULL,
    milestone_name VARCHAR(100)
);
ALTER TABLE project_milestones_existing
ADD CONSTRAINT FK_project_milestones_existing_projects
FOREIGN KEY (project_id) REFERENCES projects(project_id);


/* ================================================================
   TASK 2 - LOGICAL AND SPECIAL OPERATORS
   ================================================================ */

-- Part 1
-- A. Salary > 5000 and < 7000.
SELECT * FROM employees WHERE salary > 5000 AND salary < 7000;
-- B. Salary is 7000 or 8000.
SELECT * FROM employees WHERE salary IN (7000, 8000);
-- C. No phone number.
SELECT * FROM employees WHERE phone_number IS NULL;
-- D. Salary between 9000 and 12000 inclusive.
SELECT * FROM employees WHERE salary BETWEEN 9000 AND 12000;
-- E. Department 8 or 9.
SELECT * FROM employees WHERE department_id IN (8, 9);
-- F. First name starts with jo.
SELECT * FROM employees WHERE first_name LIKE 'jo%';
-- G. Second character is h.
SELECT * FROM employees WHERE first_name LIKE '_h%';
-- H. Salary greater than ALL salaries in department 8.
SELECT * FROM employees
WHERE salary > ALL (SELECT salary FROM employees WHERE department_id = 8);

-- Part 2
-- A. Salary greater than the average salary of every department.
SELECT *
FROM employees
WHERE salary > ALL
(
    SELECT AVG(salary)
    FROM employees
    WHERE department_id IS NOT NULL
    GROUP BY department_id
);
-- B. Employees who have dependents.
SELECT e.*
FROM employees e
WHERE EXISTS
(
    SELECT 1 FROM dependents d
    WHERE d.employee_id = e.employee_id
);
-- C. Salary between 2500 and 2900.
SELECT * FROM employees WHERE salary BETWEEN 2500 AND 2900;
-- D. Salary not between 2500 and 2900.
SELECT * FROM employees WHERE salary NOT BETWEEN 2500 AND 2900;
-- E. Joined 1 Jan 1999 through 31 Dec 2000 inclusive.
SELECT * FROM employees
WHERE hire_date >= '1999-01-01' AND hire_date < '2001-01-01';
-- F. Not joined from 1 Jan 1989 through 31 Dec 1999.
SELECT * FROM employees
WHERE hire_date < '1989-01-01' OR hire_date >= '2000-01-01';
-- G. Joined during 1990-1993 inclusive.
SELECT * FROM employees
WHERE hire_date >= '1990-01-01' AND hire_date < '1994-01-01';

-- Part 3: LIKE patterns
-- A. First names start with Da.
SELECT * FROM employees WHERE first_name LIKE 'Da%';
-- B. First names end with er.
SELECT * FROM employees WHERE first_name LIKE '%er';
-- C. Last names contain an.
SELECT * FROM employees WHERE last_name LIKE '%an%';
-- D. Starts Jo followed by at most two characters (Jo, Jon, John).
SELECT * FROM employees WHERE first_name LIKE 'Jo' OR first_name LIKE 'Jo_' OR first_name LIKE 'Jo__';
-- E. Any prefix followed by at most one character is too broad as written;
--    SQL pattern for any name of length 1 or more ending with at most one extra character:
SELECT * FROM employees WHERE LEN(first_name) >= 1;
-- F. Starts S but not Sh.
SELECT * FROM employees
WHERE first_name LIKE 'S%' AND first_name NOT LIKE 'Sh%';

-- Part 4
-- A. Department 5.
SELECT * FROM employees WHERE department_id = 5;
-- B. Department 5 and salary <= 5000.
SELECT * FROM employees WHERE department_id = 5 AND salary <= 5000;
-- C. Not in departments 1, 2, 3.
SELECT * FROM employees WHERE department_id NOT IN (1, 2, 3);
-- D. First names do not start with D.
SELECT * FROM employees WHERE first_name NOT LIKE 'D%';
-- E. Literal interpretation: salary not between 1000 and 5000.
SELECT * FROM employees WHERE salary NOT BETWEEN 1000 AND 5000;

-- Part 5
-- A. Employees without dependents.
SELECT e.*
FROM employees e
WHERE NOT EXISTS (SELECT 1 FROM dependents d WHERE d.employee_id = e.employee_id);
-- B. No phone number.
SELECT * FROM employees WHERE phone_number IS NULL;
-- C. Has a phone number.
SELECT * FROM employees WHERE phone_number IS NOT NULL;


/* ================================================================
   TASK 3 - JOINS
   ================================================================ */

-- INNER JOIN
-- A. Department IDs 1, 2, 3 (department information).
SELECT * FROM departments WHERE department_id IN (1, 2, 3);
-- B. Employees in departments 1, 2, 3.
SELECT * FROM employees WHERE department_id IN (1, 2, 3);
-- Employee name, job title and department name for departments 1-3.
SELECT e.first_name, e.last_name, j.job_title, d.department_name
FROM employees e
INNER JOIN jobs j ON e.job_id = j.job_id
INNER JOIN departments d ON e.department_id = d.department_id
WHERE d.department_id IN (1, 2, 3);

-- LEFT JOIN
-- A. Country names US, UK and China.
SELECT country_id, country_name
FROM countries
WHERE country_id IN ('US', 'UK', 'CN');
-- B. Locations in US, UK and China.
SELECT l.*
FROM locations l
INNER JOIN countries c ON l.country_id = c.country_id
WHERE c.country_id IN ('US', 'UK', 'CN');
-- C. Join countries with locations (also show countries without locations).
SELECT c.country_name, l.location_id, l.city
FROM countries c
LEFT JOIN locations l ON c.country_id = l.country_id;
-- D. Countries without locations.
SELECT c.*
FROM countries c
LEFT JOIN locations l ON c.country_id = l.country_id
WHERE l.location_id IS NULL;
-- Join regions, countries and locations.
SELECT r.region_name, c.country_name, l.location_id, l.city
FROM regions r
INNER JOIN countries c ON r.region_id = c.region_id
LEFT JOIN locations l ON c.country_id = l.country_id
ORDER BY r.region_name, c.country_name;

-- SELF JOIN: employee and manager.
SELECT e.employee_id, e.first_name AS employee_first_name,
       e.last_name AS employee_last_name,
       m.employee_id AS manager_id,
       m.first_name AS manager_first_name,
       m.last_name AS manager_last_name
FROM employees e
INNER JOIN employees m ON e.manager_id = m.employee_id;
-- Include the president (and any employee without a manager).
SELECT e.employee_id, e.first_name, e.last_name,
       m.first_name AS manager_first_name, m.last_name AS manager_last_name
FROM employees e
LEFT JOIN employees m ON e.manager_id = m.employee_id;

-- FULL OUTER JOIN demonstration.
CREATE TABLE baskets
(
    basket_id INT PRIMARY KEY,
    basket_name VARCHAR(255) NOT NULL
);
CREATE TABLE fruits
(
    fruit_id INT PRIMARY KEY,
    fruit_name VARCHAR(255) NOT NULL,
    basket_id INT NULL
);
INSERT INTO baskets (basket_id, basket_name)
VALUES (1, 'A'), (2, 'B'), (3, 'C');
INSERT INTO fruits (fruit_id, fruit_name, basket_id)
VALUES (1, 'Apple', 1), (2, 'Orange', 1), (3, 'Banana', 2), (4, 'Strawberry', NULL);
-- A. All matched and unmatched baskets/fruits.
SELECT b.basket_id, b.basket_name, f.fruit_id, f.fruit_name
FROM baskets b
FULL OUTER JOIN fruits f ON b.basket_id = f.basket_id;
-- B. Empty baskets.
SELECT b.*
FROM baskets b
LEFT JOIN fruits f ON b.basket_id = f.basket_id
WHERE f.fruit_id IS NULL;
-- C. Fruits not in any basket.
SELECT f.*
FROM fruits f
LEFT JOIN baskets b ON f.basket_id = b.basket_id
WHERE b.basket_id IS NULL;

-- CROSS JOIN: all sales organization/channel combinations.
CREATE TABLE sales_organization
(
    sales_org_id INT PRIMARY KEY,
    sales_org VARCHAR(255)
);
CREATE TABLE sales_channel
(
    channel_id INT PRIMARY KEY,
    channel VARCHAR(255)
);
INSERT INTO sales_organization (sales_org_id, sales_org)
VALUES (1, 'Domestic'), (2, 'Export');
INSERT INTO sales_channel (channel_id, channel)
VALUES (1, 'Wholesale'), (2, 'Retail'), (3, 'eCommerce'), (4, 'TV Shopping');
SELECT so.sales_org, sc.channel
FROM sales_organization so
CROSS JOIN sales_channel sc
ORDER BY so.sales_org, sc.channel;


/* ================================================================
   TASK 4 - GROUP BY AND HAVING
   ================================================================ */

-- A. Unique department IDs / groups.
SELECT department_id FROM employees
GROUP BY department_id;
-- B-C. Employee count by department.
SELECT department_id, COUNT(*) AS employee_count
FROM employees
GROUP BY department_id;
-- D. Sort departments by headcount (largest first).
SELECT department_id, COUNT(*) AS employee_count
FROM employees
GROUP BY department_id
ORDER BY employee_count DESC;
-- E. Departments with more than 5 employees.
SELECT department_id, COUNT(*) AS employee_count
FROM employees
GROUP BY department_id
HAVING COUNT(*) > 5;
-- F. Minimum, maximum and average salary by department.
SELECT department_id, MIN(salary) AS minimum_salary,
       MAX(salary) AS maximum_salary, AVG(salary) AS average_salary
FROM employees
GROUP BY department_id;
-- G. Total salary by department.
SELECT department_id, SUM(salary) AS total_salary
FROM employees
GROUP BY department_id;
-- H. Group by department and job.
SELECT department_id, job_id, COUNT(*) AS employee_count,
       SUM(salary) AS total_salary
FROM employees
GROUP BY department_id, job_id
ORDER BY department_id, job_id;

-- HAVING
-- A. Managers and number of direct reports.
SELECT manager_id, COUNT(*) AS direct_reports
FROM employees
WHERE manager_id IS NOT NULL
GROUP BY manager_id;
-- B. Managers with at least five direct reports.
SELECT manager_id, COUNT(*) AS direct_reports
FROM employees
WHERE manager_id IS NOT NULL
GROUP BY manager_id
HAVING COUNT(*) >= 5;
-- C. Department salary totals between 20000 and 30000.
SELECT department_id, SUM(salary) AS total_salary
FROM employees
GROUP BY department_id
HAVING SUM(salary) BETWEEN 20000 AND 30000;
-- D. Departments whose lowest employee salary is greater than 10000.
SELECT department_id, MIN(salary) AS lowest_salary
FROM employees
GROUP BY department_id
HAVING MIN(salary) > 10000;
-- E. Departments with average salary between 5000 and 7000.
SELECT department_id, AVG(salary) AS average_salary
FROM employees
GROUP BY department_id
HAVING AVG(salary) BETWEEN 5000 AND 7000;


/* ================================================================
   TASK 5 - UNION, INTERSECT, EXISTS, CASE, UPDATE
   ================================================================ */

-- 1. UNION: employee names and dependent names in one result.
SELECT first_name, last_name, 'Employee' AS person_type
FROM employees
UNION
SELECT first_name, last_name, 'Dependent' AS person_type
FROM dependents;

-- 2. INTERSECT example: A and B sets, sorted by id descending.
-- SQL Server INTERSECT returns rows common to both queries.
SELECT id FROM (VALUES (1), (2)) AS A(id)
INTERSECT
SELECT id FROM (VALUES (2), (3)) AS B(id)
ORDER BY id DESC;

-- 3. EXISTS
-- A. Employees with at least one dependent.
SELECT e.*
FROM employees e
WHERE EXISTS (SELECT 1 FROM dependents d WHERE d.employee_id = e.employee_id);
-- B. Employees without dependents.
SELECT e.*
FROM employees e
WHERE NOT EXISTS (SELECT 1 FROM dependents d WHERE d.employee_id = e.employee_id);

-- 4. CASE
-- A. Work anniversaries assuming the year 2000.
SELECT employee_id, first_name, last_name, hire_date,
       DATEDIFF(YEAR, hire_date, '2000-12-31') AS completed_years_of_service,
       CASE
           WHEN MONTH(hire_date) = 1 AND DAY(hire_date) <= 31 THEN 'January anniversary'
           WHEN MONTH(hire_date) = 2 THEN 'February anniversary'
           WHEN MONTH(hire_date) = 3 THEN 'March anniversary'
           WHEN MONTH(hire_date) = 4 THEN 'April anniversary'
           WHEN MONTH(hire_date) = 5 THEN 'May anniversary'
           WHEN MONTH(hire_date) = 6 THEN 'June anniversary'
           WHEN MONTH(hire_date) = 7 THEN 'July anniversary'
           WHEN MONTH(hire_date) = 8 THEN 'August anniversary'
           WHEN MONTH(hire_date) = 9 THEN 'September anniversary'
           WHEN MONTH(hire_date) = 10 THEN 'October anniversary'
           WHEN MONTH(hire_date) = 11 THEN 'November anniversary'
           ELSE 'December anniversary'
       END AS anniversary_month
FROM employees;
-- B. Salary catery.
SELECT employee_id, first_name, last_name, salary,
       CASE
           WHEN salary < 3000 THEN 'Low'
           WHEN salary BETWEEN 3000 AND 5000 THEN 'Average'
           WHEN salary > 5000 THEN 'High'
       END AS salary_catery
FROM employees;

-- 5. UPDATE Sarah Bell (employee 192) to Lopez.
UPDATE employees
SET last_name = 'Lopez'
WHERE employee_id = 192 AND last_name = 'Bell';
-- Keep dependents' surnames aligned when a parent's surname changes.
-- One-time synchronization for dependents of employee 192:
UPDATE d
SET d.last_name = e.last_name
FROM dependents d
INNER JOIN employees e ON d.employee_id = e.employee_id
WHERE e.employee_id = 192;


/* ================================================================
   FINAL TASK - ADVANCED SUBQUERIES
   ================================================================ */

-- A. Employees in departments located at location 1700.
SELECT employee_id, first_name, last_name
FROM employees
WHERE department_id IN
(
    SELECT department_id
    FROM departments
    WHERE location_id = 1700
)
ORDER BY first_name, last_name;

-- B. Employees not located at location 1700 (NULL department excluded).
SELECT employee_id, first_name, last_name
FROM employees
WHERE department_id IN
(
    SELECT department_id
    FROM departments
    WHERE location_id <> 1700
       OR location_id IS NULL
);

-- C. Employees with the highest salary.
SELECT *
FROM employees
WHERE salary = (SELECT MAX(salary) FROM employees);

-- D. Salary greater than company average.
SELECT *
FROM employees
WHERE salary > (SELECT AVG(salary) FROM employees);

-- E. Departments with at least one employee earning > 10000.
SELECT *
FROM departments d
WHERE EXISTS
(
    SELECT 1 FROM employees e
    WHERE e.department_id = d.department_id AND e.salary > 10000
);

-- F. Departments with no employee earning > 10000.
SELECT *
FROM departments d
WHERE NOT EXISTS
(
    SELECT 1 FROM employees e
    WHERE e.department_id = d.department_id AND e.salary > 10000
);

-- G. Lowest salary by department.
SELECT department_id, MIN(salary) AS lowest_salary
FROM employees
GROUP BY department_id;

-- H. Employees earning more than the lowest salary in every department.
SELECT *
FROM employees
WHERE salary > ALL
(
    SELECT MIN(salary)
    FROM employees
    WHERE department_id IS NOT NULL
    GROUP BY department_id
);

-- I. Employees earning >= the highest salary in every department.
SELECT *
FROM employees
WHERE salary >= ALL
(
    SELECT MAX(salary)
    FROM employees
    WHERE department_id IS NOT NULL
    GROUP BY department_id
);

-- J. Average salary of each department.
SELECT department_id, AVG(salary) AS average_salary
FROM employees
GROUP BY department_id;

-- K. Average of the departmental average salaries.
SELECT AVG(department_average) AS average_of_department_averages
FROM
(
    SELECT department_id, AVG(salary) AS department_average
    FROM employees
    WHERE department_id IS NOT NULL
    GROUP BY department_id
) AS DepartmentAverages;

-- L. Each employee's salary, company average and difference from average.
SELECT employee_id, first_name, last_name, salary,
       AVG(salary) OVER () AS company_average_salary,
       salary - AVG(salary) OVER () AS difference_from_average
FROM employees
ORDER BY employee_id;


/* ================================================================
   PROJECT VALIDATION / KEY FINDINGS
   ================================================================ */

-- Confirm row counts for the seven HR tables.
SELECT 'regions' AS table_name, COUNT(*) AS total_rows FROM regions
UNION ALL SELECT 'countries', COUNT(*) FROM countries
UNION ALL SELECT 'locations', COUNT(*) FROM locations
UNION ALL SELECT 'jobs', COUNT(*) FROM jobs
UNION ALL SELECT 'departments', COUNT(*) FROM departments
UNION ALL SELECT 'employees', COUNT(*) FROM employees
UNION ALL SELECT 'dependents', COUNT(*) FROM dependents;

-- Employee count and payroll by department.
SELECT d.department_name, COUNT(e.employee_id) AS employee_count,
       COALESCE(SUM(e.salary), 0) AS monthly_payroll
FROM departments d
LEFT JOIN employees e ON d.department_id = e.department_id
GROUP BY d.department_name
ORDER BY employee_count DESC;

-- Employee count by region.
SELECT r.region_name, COUNT(DISTINCT e.employee_id) AS employee_count
FROM regions r
LEFT JOIN countries c ON r.region_id = c.region_id
LEFT JOIN locations l ON c.country_id = l.country_id
LEFT JOIN departments d ON l.location_id = d.location_id
LEFT JOIN employees e ON d.department_id = e.department_id
GROUP BY r.region_name
ORDER BY r.region_name;

